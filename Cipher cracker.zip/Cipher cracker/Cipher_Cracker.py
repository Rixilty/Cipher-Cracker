уже = False
Current_line = 0

Consecs = []
Highest_Consecs = 0

alpha = ["a", "b", "c", "d", "e", "f", "g", "h", "i", "j", "k", "l", "m", "n", "o", "p", "q", "r", "s", "t", "u", "v",
         "w", "x", "y", "z"]
num = ["0", "1", "2", "3", "4", "5", "6", "7", "8", "9"]


def Главное_меню():
    global Text, Text_Length, List, Current_Character, codes
    Text = input("Enter the text you want to crack: ")
    Text_Length = len(Text)

    Binary_Code = []
    List = []
    Code = []

    with open('Cipher_Codes.txt', 'r') as f:
        binary = []
        lists = []
        codes = []
        for line in f:
            parts = line.strip().split('::')
            binary.append(parts[0])
            lists.append(parts[1].strip().split())
            codes.append(parts[2])

        for i in range(32):
            Current_Character = 0
            Code = codes[i]
            Binary_Code = binary[i]
            List = lists[i]
            Code = codes[i]
            Decrypter()

        func()


def Decrypter():
    global Text, Text_Length, Current_Character, Non_Encrypted_List, Encrypted_List, Num, Consecs

    Non_Encrypted_List = ["A", "B", "C", "D", "E", "F", "G", "H", "I", "J", "K", "L", "M", "N", "O", "P", "Q", "R", "S",
                          "T", "U", "V", "W", "X", "Y", "Z", "a", "b", "c", "d", "e", "f", "g", "h", "i", "j", "k", "l",
                          "m", "n", "o", "p", "q", "r", "s", "t", "u", "v", "w", "x", "y", "z", "0", "1", "2", "3", "4",
                          "5", "6", "7", "8", "9", "!", "@", "#", "$", "%", "^", "&", "*", "(", ")", "-", "_", "+", "=",
                          "[", "]", "{", "}", "|", ";", ":", ".", "<", ">", "/", "?", "`"]
    Encrypted_List = List

    Decrypted_Text = ""

    for i in range(Text_Length):
        Num = 0
        found_match = False
        while not found_match and Num < len(Non_Encrypted_List):
            if Num > len(Non_Encrypted_List):
                break
            elif Text[Current_Character] == Encrypted_List[Num]:
                Decrypted_Text += Non_Encrypted_List[Num]
                Current_Character += 1
                found_match = True
            else:
                Num += 1

        if not found_match:
            Decrypted_Text += Text[Current_Character]
            Current_Character += 1

    Consecs.append(Decrypted_Text)


def func():

    Consecs_Total_Sores = []

    for i in range(len(Consecs)):
        Letter_Consec = 0
        Number_Consec = 0
        Symbol_Consec = 0

        for j in range(len(Consecs[i])):
            prev_char = Consecs[i][j - 1] if j > 0 else None

            if j == 0:
                continue
            if Consecs[i][j] in alpha and prev_char in alpha:
                Letter_Consec += 1
            elif Consecs[i][j] in num and prev_char in num:
                Number_Consec += 1
            elif (Consecs[i][j] in num and prev_char not in num) or (Consecs[i][j] in alpha and prev_char not in alpha):
                Symbol_Consec += 1
            else:
                continue

        score = Letter_Consec + Number_Consec

        Consecs_Total_Sores.append(score)

    Highest_Score_Index = Consecs_Total_Sores.index(max(Consecs_Total_Sores))

    print("Cracked text:",Consecs[Highest_Score_Index])
    print("Code used:",codes[Highest_Score_Index])


Главное_меню()
